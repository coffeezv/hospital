from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import DoctorViewSet, ServiceViewSet, VisitViewSet

router = DefaultRouter()
router.register(r'doctors', DoctorViewSet)
router.register(r'services', ServiceViewSet)
router.register(r'visits', VisitViewSet)

urlpatterns = [
    path('', include(router.urls)),
]