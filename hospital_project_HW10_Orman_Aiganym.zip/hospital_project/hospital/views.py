
from rest_framework import mixins, viewsets
from .models import Service
from .serializers import ServiceSerializer
from .models import Visit
from .serializers import VisitSerializer
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Doctor, Patient
from .serializers import DoctorSerializer, PatientSerializer

class DoctorViewSet(viewsets.ModelViewSet):
    queryset = Doctor.objects.all()
    serializer_class = DoctorSerializer

    @action(detail=True, methods=['get'])
    def patients(self, request, pk=None):
        doctor = self.get_object()
        visits = Visit.objects.filter(doctor=doctor)
        patients = Patient.objects.filter(id__in=visits.values_list('patient', flat=True)).distinct()
        serializer = PatientSerializer(patients, many=True)
        return Response(serializer.data)


class ServiceViewSet(mixins.ListModelMixin,
                     mixins.CreateModelMixin,
                     mixins.RetrieveModelMixin,
                     mixins.UpdateModelMixin,
                     mixins.DestroyModelMixin,
                     viewsets.GenericViewSet):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer

class VisitViewSet(mixins.ListModelMixin,
                   mixins.CreateModelMixin,
                   mixins.RetrieveModelMixin,
                   mixins.UpdateModelMixin,
                   mixins.DestroyModelMixin,
                   viewsets.GenericViewSet):
    queryset = Visit.objects.all()
    serializer_class = VisitSerializer
