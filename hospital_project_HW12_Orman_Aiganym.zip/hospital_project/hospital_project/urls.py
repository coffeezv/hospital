from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('hospital.urls')),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),  # логин
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),  # обновление токена
]
